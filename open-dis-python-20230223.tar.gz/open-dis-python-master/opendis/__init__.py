# Marker for a python package directory
name = "opendis"
